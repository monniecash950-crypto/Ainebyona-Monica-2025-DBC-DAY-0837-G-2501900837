﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtDailyRentalCharge = New System.Windows.Forms.TextBox()
        Me.lblDailyRentalCharge = New System.Windows.Forms.Label()
        Me.lblCARRENTALSYSTEM = New System.Windows.Forms.Label()
        Me.lblFIRSTLOGISTICSCOMPANY = New System.Windows.Forms.Label()
        Me.btnCLEAR = New System.Windows.Forms.Button()
        Me.btnCALCULATE = New System.Windows.Forms.Button()
        Me.lblTotalRentalCost = New System.Windows.Forms.Label()
        Me.txtTotalRentalCost = New System.Windows.Forms.TextBox()
        Me.txtRentalDuration = New System.Windows.Forms.TextBox()
        Me.lblRentalDuration = New System.Windows.Forms.Label()
        Me.cmbVehicleType = New System.Windows.Forms.ComboBox()
        Me.lblVehicleType = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'txtDailyRentalCharge
        '
        Me.txtDailyRentalCharge.Location = New System.Drawing.Point(501, 276)
        Me.txtDailyRentalCharge.Margin = New System.Windows.Forms.Padding(13, 12, 13, 12)
        Me.txtDailyRentalCharge.Name = "txtDailyRentalCharge"
        Me.txtDailyRentalCharge.Size = New System.Drawing.Size(412, 26)
        Me.txtDailyRentalCharge.TabIndex = 59
        '
        'lblDailyRentalCharge
        '
        Me.lblDailyRentalCharge.AutoSize = True
        Me.lblDailyRentalCharge.Location = New System.Drawing.Point(278, 279)
        Me.lblDailyRentalCharge.Margin = New System.Windows.Forms.Padding(13, 0, 13, 0)
        Me.lblDailyRentalCharge.Name = "lblDailyRentalCharge"
        Me.lblDailyRentalCharge.Size = New System.Drawing.Size(174, 20)
        Me.lblDailyRentalCharge.TabIndex = 58
        Me.lblDailyRentalCharge.Text = "Daily Rental Charge:"
        '
        'lblCARRENTALSYSTEM
        '
        Me.lblCARRENTALSYSTEM.AutoSize = True
        Me.lblCARRENTALSYSTEM.Location = New System.Drawing.Point(513, 125)
        Me.lblCARRENTALSYSTEM.Margin = New System.Windows.Forms.Padding(13, 0, 13, 0)
        Me.lblCARRENTALSYSTEM.Name = "lblCARRENTALSYSTEM"
        Me.lblCARRENTALSYSTEM.Size = New System.Drawing.Size(197, 20)
        Me.lblCARRENTALSYSTEM.TabIndex = 57
        Me.lblCARRENTALSYSTEM.Text = "CAR RENTAL SYSTEM"
        '
        'lblFIRSTLOGISTICSCOMPANY
        '
        Me.lblFIRSTLOGISTICSCOMPANY.AutoSize = True
        Me.lblFIRSTLOGISTICSCOMPANY.Location = New System.Drawing.Point(476, 73)
        Me.lblFIRSTLOGISTICSCOMPANY.Margin = New System.Windows.Forms.Padding(13, 0, 13, 0)
        Me.lblFIRSTLOGISTICSCOMPANY.Name = "lblFIRSTLOGISTICSCOMPANY"
        Me.lblFIRSTLOGISTICSCOMPANY.Size = New System.Drawing.Size(245, 20)
        Me.lblFIRSTLOGISTICSCOMPANY.TabIndex = 56
        Me.lblFIRSTLOGISTICSCOMPANY.Text = "FAST LOGISTICS COMPANY"
        '
        'btnCLEAR
        '
        Me.btnCLEAR.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCLEAR.Location = New System.Drawing.Point(749, 483)
        Me.btnCLEAR.Margin = New System.Windows.Forms.Padding(13, 12, 13, 12)
        Me.btnCLEAR.Name = "btnCLEAR"
        Me.btnCLEAR.Size = New System.Drawing.Size(164, 48)
        Me.btnCLEAR.TabIndex = 55
        Me.btnCLEAR.Text = "CLEAR"
        Me.btnCLEAR.UseVisualStyleBackColor = True
        '
        'btnCALCULATE
        '
        Me.btnCALCULATE.Location = New System.Drawing.Point(396, 480)
        Me.btnCALCULATE.Margin = New System.Windows.Forms.Padding(13, 12, 13, 12)
        Me.btnCALCULATE.Name = "btnCALCULATE"
        Me.btnCALCULATE.Size = New System.Drawing.Size(219, 51)
        Me.btnCALCULATE.TabIndex = 54
        Me.btnCALCULATE.Text = "CALCULATE"
        Me.btnCALCULATE.UseVisualStyleBackColor = True
        '
        'lblTotalRentalCost
        '
        Me.lblTotalRentalCost.AutoSize = True
        Me.lblTotalRentalCost.Location = New System.Drawing.Point(278, 427)
        Me.lblTotalRentalCost.Margin = New System.Windows.Forms.Padding(13, 0, 13, 0)
        Me.lblTotalRentalCost.Name = "lblTotalRentalCost"
        Me.lblTotalRentalCost.Size = New System.Drawing.Size(154, 20)
        Me.lblTotalRentalCost.TabIndex = 53
        Me.lblTotalRentalCost.Text = "Total Rental Cost:"
        '
        'txtTotalRentalCost
        '
        Me.txtTotalRentalCost.Location = New System.Drawing.Point(501, 421)
        Me.txtTotalRentalCost.Margin = New System.Windows.Forms.Padding(13, 12, 13, 12)
        Me.txtTotalRentalCost.Name = "txtTotalRentalCost"
        Me.txtTotalRentalCost.Size = New System.Drawing.Size(412, 26)
        Me.txtTotalRentalCost.TabIndex = 52
        '
        'txtRentalDuration
        '
        Me.txtRentalDuration.Location = New System.Drawing.Point(501, 345)
        Me.txtRentalDuration.Margin = New System.Windows.Forms.Padding(13, 12, 13, 12)
        Me.txtRentalDuration.Name = "txtRentalDuration"
        Me.txtRentalDuration.Size = New System.Drawing.Size(412, 26)
        Me.txtRentalDuration.TabIndex = 51
        '
        'lblRentalDuration
        '
        Me.lblRentalDuration.AutoSize = True
        Me.lblRentalDuration.Location = New System.Drawing.Point(291, 351)
        Me.lblRentalDuration.Margin = New System.Windows.Forms.Padding(13, 0, 13, 0)
        Me.lblRentalDuration.Name = "lblRentalDuration"
        Me.lblRentalDuration.Size = New System.Drawing.Size(141, 20)
        Me.lblRentalDuration.TabIndex = 50
        Me.lblRentalDuration.Text = "Rental Duration:"
        '
        'cmbVehicleType
        '
        Me.cmbVehicleType.FormattingEnabled = True
        Me.cmbVehicleType.Location = New System.Drawing.Point(501, 204)
        Me.cmbVehicleType.Margin = New System.Windows.Forms.Padding(13, 12, 13, 12)
        Me.cmbVehicleType.Name = "cmbVehicleType"
        Me.cmbVehicleType.Size = New System.Drawing.Size(412, 28)
        Me.cmbVehicleType.TabIndex = 49
        '
        'lblVehicleType
        '
        Me.lblVehicleType.AutoSize = True
        Me.lblVehicleType.Location = New System.Drawing.Point(291, 207)
        Me.lblVehicleType.Margin = New System.Windows.Forms.Padding(27, 0, 27, 0)
        Me.lblVehicleType.Name = "lblVehicleType"
        Me.lblVehicleType.Size = New System.Drawing.Size(116, 20)
        Me.lblVehicleType.TabIndex = 48
        Me.lblVehicleType.Text = "Vehicle Type:"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1924, 994)
        Me.Controls.Add(Me.txtDailyRentalCharge)
        Me.Controls.Add(Me.lblDailyRentalCharge)
        Me.Controls.Add(Me.lblCARRENTALSYSTEM)
        Me.Controls.Add(Me.lblFIRSTLOGISTICSCOMPANY)
        Me.Controls.Add(Me.btnCLEAR)
        Me.Controls.Add(Me.btnCALCULATE)
        Me.Controls.Add(Me.lblTotalRentalCost)
        Me.Controls.Add(Me.txtTotalRentalCost)
        Me.Controls.Add(Me.txtRentalDuration)
        Me.Controls.Add(Me.lblRentalDuration)
        Me.Controls.Add(Me.cmbVehicleType)
        Me.Controls.Add(Me.lblVehicleType)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtDailyRentalCharge As System.Windows.Forms.TextBox
    Friend WithEvents lblDailyRentalCharge As System.Windows.Forms.Label
    Friend WithEvents lblCARRENTALSYSTEM As System.Windows.Forms.Label
    Friend WithEvents lblFIRSTLOGISTICSCOMPANY As System.Windows.Forms.Label
    Friend WithEvents btnCLEAR As System.Windows.Forms.Button
    Friend WithEvents btnCALCULATE As System.Windows.Forms.Button
    Friend WithEvents lblTotalRentalCost As System.Windows.Forms.Label
    Friend WithEvents txtTotalRentalCost As System.Windows.Forms.TextBox
    Friend WithEvents txtRentalDuration As System.Windows.Forms.TextBox
    Friend WithEvents lblRentalDuration As System.Windows.Forms.Label
    Friend WithEvents cmbVehicleType As System.Windows.Forms.ComboBox
    Friend WithEvents lblVehicleType As System.Windows.Forms.Label

End Class
