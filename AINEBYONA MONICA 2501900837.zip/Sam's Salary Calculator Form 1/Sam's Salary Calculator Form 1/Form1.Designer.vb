﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblSamsSalaryCalculator = New System.Windows.Forms.Label()
        Me.grpInputDetails = New System.Windows.Forms.GroupBox()
        Me.txtFees = New System.Windows.Forms.TextBox()
        Me.txtDependents = New System.Windows.Forms.TextBox()
        Me.txtSalary = New System.Windows.Forms.TextBox()
        Me.lblFees = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblSalary = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblTotalExpenses = New System.Windows.Forms.Label()
        Me.lblTakeHome = New System.Windows.Forms.Label()
        Me.lblNSSF = New System.Windows.Forms.Label()
        Me.lblPAYE = New System.Windows.Forms.Label()
        Me.lblSACCO = New System.Windows.Forms.Label()
        Me.lblResults = New System.Windows.Forms.Label()
        Me.txtTotalExpenses = New System.Windows.Forms.TextBox()
        Me.txtTakeHome = New System.Windows.Forms.TextBox()
        Me.txtNSSF = New System.Windows.Forms.TextBox()
        Me.txtPAYE = New System.Windows.Forms.TextBox()
        Me.txtSACCO = New System.Windows.Forms.TextBox()
        Me.lblFinalBalance = New System.Windows.Forms.Label()
        Me.txtFinalBalance = New System.Windows.Forms.TextBox()
        Me.grpInputDetails.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblSamsSalaryCalculator
        '
        Me.lblSamsSalaryCalculator.AutoSize = True
        Me.lblSamsSalaryCalculator.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.lblSamsSalaryCalculator.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblSamsSalaryCalculator.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSamsSalaryCalculator.Location = New System.Drawing.Point(360, 63)
        Me.lblSamsSalaryCalculator.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.lblSamsSalaryCalculator.Name = "lblSamsSalaryCalculator"
        Me.lblSamsSalaryCalculator.Size = New System.Drawing.Size(333, 31)
        Me.lblSamsSalaryCalculator.TabIndex = 0
        Me.lblSamsSalaryCalculator.Text = "Sam's  Salary Calculator"
        '
        'grpInputDetails
        '
        Me.grpInputDetails.Controls.Add(Me.txtFees)
        Me.grpInputDetails.Controls.Add(Me.txtDependents)
        Me.grpInputDetails.Controls.Add(Me.txtSalary)
        Me.grpInputDetails.Controls.Add(Me.lblFees)
        Me.grpInputDetails.Controls.Add(Me.Label2)
        Me.grpInputDetails.Controls.Add(Me.lblSalary)
        Me.grpInputDetails.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpInputDetails.Location = New System.Drawing.Point(78, 99)
        Me.grpInputDetails.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.grpInputDetails.Name = "grpInputDetails"
        Me.grpInputDetails.Padding = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.grpInputDetails.Size = New System.Drawing.Size(778, 237)
        Me.grpInputDetails.TabIndex = 1
        Me.grpInputDetails.TabStop = False
        Me.grpInputDetails.Text = "Input Details"
        '
        'txtFees
        '
        Me.txtFees.Location = New System.Drawing.Point(346, 165)
        Me.txtFees.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.txtFees.Name = "txtFees"
        Me.txtFees.Size = New System.Drawing.Size(342, 30)
        Me.txtFees.TabIndex = 5
        '
        'txtDependents
        '
        Me.txtDependents.Location = New System.Drawing.Point(268, 105)
        Me.txtDependents.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.txtDependents.Name = "txtDependents"
        Me.txtDependents.Size = New System.Drawing.Size(429, 30)
        Me.txtDependents.TabIndex = 4
        '
        'txtSalary
        '
        Me.txtSalary.Location = New System.Drawing.Point(240, 42)
        Me.txtSalary.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.txtSalary.Name = "txtSalary"
        Me.txtSalary.Size = New System.Drawing.Size(482, 30)
        Me.txtSalary.TabIndex = 3
        '
        'lblFees
        '
        Me.lblFees.AutoSize = True
        Me.lblFees.Location = New System.Drawing.Point(28, 165)
        Me.lblFees.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.lblFees.Name = "lblFees"
        Me.lblFees.Size = New System.Drawing.Size(308, 25)
        Me.lblFees.TabIndex = 2
        Me.lblFees.Text = "School Fees per Dependent(ugx):"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(55, 108)
        Me.Label2.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(219, 25)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Number of Dependents:"
        '
        'lblSalary
        '
        Me.lblSalary.AutoSize = True
        Me.lblSalary.Location = New System.Drawing.Point(40, 45)
        Me.lblSalary.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.lblSalary.Name = "lblSalary"
        Me.lblSalary.Size = New System.Drawing.Size(194, 25)
        Me.lblSalary.TabIndex = 0
        Me.lblSalary.Text = "Monthly Salary(ugx):"
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(100, 360)
        Me.btnCalculate.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(125, 33)
        Me.btnCalculate.TabIndex = 2
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(390, 360)
        Me.btnClear.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(125, 33)
        Me.btnClear.TabIndex = 3
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(650, 360)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(125, 33)
        Me.btnExit.TabIndex = 4
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblTotalExpenses
        '
        Me.lblTotalExpenses.AutoSize = True
        Me.lblTotalExpenses.Location = New System.Drawing.Point(175, 499)
        Me.lblTotalExpenses.Name = "lblTotalExpenses"
        Me.lblTotalExpenses.Size = New System.Drawing.Size(151, 18)
        Me.lblTotalExpenses.TabIndex = 5
        Me.lblTotalExpenses.Text = "Total School Fees:"
        '
        'lblTakeHome
        '
        Me.lblTakeHome.AutoSize = True
        Me.lblTakeHome.Location = New System.Drawing.Point(152, 551)
        Me.lblTakeHome.Name = "lblTakeHome"
        Me.lblTakeHome.Size = New System.Drawing.Size(165, 18)
        Me.lblTakeHome.TabIndex = 6
        Me.lblTakeHome.Text = "Take Home Balance:"
        '
        'lblNSSF
        '
        Me.lblNSSF.AutoSize = True
        Me.lblNSSF.Location = New System.Drawing.Point(223, 606)
        Me.lblNSSF.Name = "lblNSSF"
        Me.lblNSSF.Size = New System.Drawing.Size(101, 18)
        Me.lblNSSF.TabIndex = 7
        Me.lblNSSF.Text = "NSSF(10%):"
        '
        'lblPAYE
        '
        Me.lblPAYE.AutoSize = True
        Me.lblPAYE.Location = New System.Drawing.Point(232, 673)
        Me.lblPAYE.Name = "lblPAYE"
        Me.lblPAYE.Size = New System.Drawing.Size(90, 18)
        Me.lblPAYE.TabIndex = 8
        Me.lblPAYE.Text = "PAYE(9%):"
        '
        'lblSACCO
        '
        Me.lblSACCO.AutoSize = True
        Me.lblSACCO.Location = New System.Drawing.Point(232, 735)
        Me.lblSACCO.Name = "lblSACCO"
        Me.lblSACCO.Size = New System.Drawing.Size(106, 18)
        Me.lblSACCO.TabIndex = 9
        Me.lblSACCO.Text = "SACCO(5%):"
        '
        'lblResults
        '
        Me.lblResults.AutoSize = True
        Me.lblResults.Font = New System.Drawing.Font("Microsoft Sans Serif", 25.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.World, CType(0, Byte))
        Me.lblResults.Location = New System.Drawing.Point(387, 433)
        Me.lblResults.Name = "lblResults"
        Me.lblResults.Size = New System.Drawing.Size(105, 29)
        Me.lblResults.TabIndex = 10
        Me.lblResults.Text = "Results"
        '
        'txtTotalExpenses
        '
        Me.txtTotalExpenses.Location = New System.Drawing.Point(346, 499)
        Me.txtTotalExpenses.Name = "txtTotalExpenses"
        Me.txtTotalExpenses.Size = New System.Drawing.Size(169, 24)
        Me.txtTotalExpenses.TabIndex = 11
        '
        'txtTakeHome
        '
        Me.txtTakeHome.Location = New System.Drawing.Point(346, 548)
        Me.txtTakeHome.Name = "txtTakeHome"
        Me.txtTakeHome.Size = New System.Drawing.Size(169, 24)
        Me.txtTakeHome.TabIndex = 12
        '
        'txtNSSF
        '
        Me.txtNSSF.Location = New System.Drawing.Point(346, 606)
        Me.txtNSSF.Name = "txtNSSF"
        Me.txtNSSF.Size = New System.Drawing.Size(215, 24)
        Me.txtNSSF.TabIndex = 13
        '
        'txtPAYE
        '
        Me.txtPAYE.Location = New System.Drawing.Point(377, 667)
        Me.txtPAYE.Name = "txtPAYE"
        Me.txtPAYE.Size = New System.Drawing.Size(184, 24)
        Me.txtPAYE.TabIndex = 14
        '
        'txtSACCO
        '
        Me.txtSACCO.Location = New System.Drawing.Point(377, 732)
        Me.txtSACCO.Name = "txtSACCO"
        Me.txtSACCO.Size = New System.Drawing.Size(207, 24)
        Me.txtSACCO.TabIndex = 15
        '
        'lblFinalBalance
        '
        Me.lblFinalBalance.AutoSize = True
        Me.lblFinalBalance.Location = New System.Drawing.Point(223, 794)
        Me.lblFinalBalance.Name = "lblFinalBalance"
        Me.lblFinalBalance.Size = New System.Drawing.Size(203, 18)
        Me.lblFinalBalance.TabIndex = 16
        Me.lblFinalBalance.Text = "Balance After Deductions:"
        '
        'txtFinalBalance
        '
        Me.txtFinalBalance.Location = New System.Drawing.Point(432, 794)
        Me.txtFinalBalance.Name = "txtFinalBalance"
        Me.txtFinalBalance.Size = New System.Drawing.Size(261, 24)
        Me.txtFinalBalance.TabIndex = 17
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1241, 839)
        Me.Controls.Add(Me.txtFinalBalance)
        Me.Controls.Add(Me.lblFinalBalance)
        Me.Controls.Add(Me.txtSACCO)
        Me.Controls.Add(Me.txtPAYE)
        Me.Controls.Add(Me.txtNSSF)
        Me.Controls.Add(Me.txtTakeHome)
        Me.Controls.Add(Me.txtTotalExpenses)
        Me.Controls.Add(Me.lblResults)
        Me.Controls.Add(Me.lblSACCO)
        Me.Controls.Add(Me.lblPAYE)
        Me.Controls.Add(Me.lblNSSF)
        Me.Controls.Add(Me.lblTakeHome)
        Me.Controls.Add(Me.lblTotalExpenses)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.grpInputDetails)
        Me.Controls.Add(Me.lblSamsSalaryCalculator)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.World, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.grpInputDetails.ResumeLayout(False)
        Me.grpInputDetails.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblSamsSalaryCalculator As System.Windows.Forms.Label
    Friend WithEvents grpInputDetails As System.Windows.Forms.GroupBox
    Friend WithEvents txtFees As System.Windows.Forms.TextBox
    Friend WithEvents txtDependents As System.Windows.Forms.TextBox
    Friend WithEvents txtSalary As System.Windows.Forms.TextBox
    Friend WithEvents lblFees As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lblSalary As System.Windows.Forms.Label
    Friend WithEvents btnCalculate As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents lblTotalExpenses As System.Windows.Forms.Label
    Friend WithEvents lblTakeHome As System.Windows.Forms.Label
    Friend WithEvents lblNSSF As System.Windows.Forms.Label
    Friend WithEvents lblPAYE As System.Windows.Forms.Label
    Friend WithEvents lblSACCO As System.Windows.Forms.Label
    Friend WithEvents lblResults As System.Windows.Forms.Label
    Friend WithEvents txtTotalExpenses As System.Windows.Forms.TextBox
    Friend WithEvents txtTakeHome As System.Windows.Forms.TextBox
    Friend WithEvents txtNSSF As System.Windows.Forms.TextBox
    Friend WithEvents txtPAYE As System.Windows.Forms.TextBox
    Friend WithEvents txtSACCO As System.Windows.Forms.TextBox
    Friend WithEvents lblFinalBalance As System.Windows.Forms.Label
    Friend WithEvents txtFinalBalance As System.Windows.Forms.TextBox

End Class
